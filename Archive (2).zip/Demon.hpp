//
//  demon.hpp
//  a7a
//
//  Created by mian wei  on 11/8/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#ifndef Demon_hpp
#define Demon_hpp
#include "Creature.hpp"
#include <string>
namespace cs_creature{

    class Demon: public Creature {
    public:
        Demon();
        Demon(int newStrength, int newHitpoints );
        int getDamage() const;
        std::string getSpecies() const;
    };
}
#endif /* demon_hpp */
