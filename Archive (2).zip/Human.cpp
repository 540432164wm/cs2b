//
//  Human.cpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#include "Human.hpp"
#include "Creature.hpp"
#include <iostream>
using namespace std;
namespace cs_creature{
    
    Human::Human(){
        
    }







    Human::Human(int newStrength,int newHitpoints)

    : Creature( newStrength, newHitpoints){
        
    }






    string Human::getSpecies() const{
        return "Human";
    }
}
