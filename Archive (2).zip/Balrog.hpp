//
//  balrog.hpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#ifndef Balrog_hpp
#define Balrog_hpp
#include "Demon.hpp"
#include <string>
namespace cs_creature{

    class Balrog: public Demon {
    public:
        Balrog();
        Balrog(int newStrength, int newHitpoints );
        int getDamage() const;
        std::string getSpecies() const;
    };
}
    #endif /* balrog_hpp */

