#include "Creature.hpp"
#include "demon.hpp"
#include "Elf.hpp"
#include "Human.hpp"
#include "cyberdemon.hpp"
#include "balrog.hpp"
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;
using namespace cs_creature;

void battleArena(Creature &Creature1, Creature& Creature2);

int main() {
    srand(time(0));
   
    Elf e(50,50);
    Balrog b(50,50);;
    
    battleArena(e, b);

}







void battleArena(Creature &Creature1, Creature& Creature2){

    while (true){
        int damage = Creature1.getDamage();
        int damage2 = Creature2.getDamage();
        int hitpoints = Creature1.getHitpoints();
        int hitpoints2 = Creature2.getHitpoints();
        
        int results = hitpoints - damage2;
        int results2 = hitpoints2 - damage;
        Creature1.setHitpoints(results);
        Creature2.setHitpoints(results2);
        if ((results <= 0)||(results2 <= 0)){
            break;
        }
    }
    if ((Creature1.getHitpoints() <= 0) && (Creature2.getHitpoints() <= 0)){
        cout << "it is a tie"<< endl;
    }else if(Creature1.getHitpoints() > Creature2.getHitpoints()){
        cout << "the " << Creature1.getSpecies() << " win!" << endl;
    }else {
        cout << "the " << Creature2.getSpecies() << " win!"<< endl;
    }
    
}

/*
 output:
 Elf attacks for 8 points!
 The Elf attacks for 8 points!
 Balrog attacks for 46 points!
 The Balrog attacks for 46 points!
 Balrog speed attack inflicts 10 additional damage points!
 the Balrog win!

 */
