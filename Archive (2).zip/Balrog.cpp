//
//  balrog.cpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#include "Balrog.hpp"
#include "Demon.hpp"
#include <iostream>
using namespace std;
namespace cs_creature{
    
    Balrog::Balrog(){
        
    }







    Balrog::Balrog(int newStrength,int newHitpoints)

    : Demon( newStrength, newHitpoints){
        
    }






    string Balrog::getSpecies() const{
        return "Balrog";
    }
    






    int Balrog::getDamage() const{
        int damage = Demon::getDamage();
        
        int damage2 = (rand() % strength) + 1;
        cout << "Balrog speed attack inflicts " << damage2 << " additional damage points!" << endl;
        damage += damage2;
        
        return damage;
    }
}
