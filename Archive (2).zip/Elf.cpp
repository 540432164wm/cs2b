//
//  Elf.cpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#include "Elf.hpp"
#include "Creature.hpp"
#include <iostream>
using namespace std;
namespace cs_creature{
    
    Elf::Elf(){
        
    }







    Elf::Elf(int newStrength,int newHitpoints)

    : Creature( newStrength, newHitpoints){
        
    }






    string Elf::getSpecies() const{
        return "Elf";
    }






    int Elf::getDamage() const{
        int damage = Creature::getDamage();
        
        if ((rand() % 2) == 0) {
            cout << "Magical attack inflicts " << damage << " additional damage points!" << endl;
            damage *= 2;
        }
        
        return damage;
    }
}
