//
//  cyberdemon.cpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#include "Cyberdemon.hpp"
#include "Demon.hpp"
#include <iostream>
using namespace std;
namespace cs_creature{
    
    Cyberdemon::Cyberdemon(){
       
    }







    Cyberdemon::Cyberdemon(int newStrength,int newHitpoints)

    : Demon( newStrength, newHitpoints){
        
    }






    string Cyberdemon::getSpecies() const{
        return "Cyberdemon";
    }
}

