//
//  creature.cpp
//  a7a
//
//  Created by mian wei  on 11/8/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#include "Creature.hpp"
#include <iostream>
#include <string>
using namespace std;
namespace cs_creature{

    Creature::Creature(){
        strength = 10;
        hitpoints = 10;
    }







    Creature::Creature(int newStrength,int newHitpoints){
        
        strength = newStrength;
        hitpoints = newHitpoints;
    }






    string Creature::getSpecies() const{
        return "Creature";
    }






    int Creature::getDamage() const {
        int damage;

        // All Creatures inflict damage which is a random number up to their strength
        damage = (rand() % strength) + 1;
        cout << getSpecies() << " attacks for " << damage << " points!" << endl;
        cout << "The " << getSpecies() << " attacks for " << damage << " points!"
             << endl;
        return damage;
    }






    int Creature::getStrength() const{
        return strength;
    }






    int Creature::getHitpoints() const{
        return hitpoints;
    }






    void Creature::setStrength(int strength){
        this -> strength = strength;
    }







    void Creature::setHitpoints(int hitpoints){
         this -> hitpoints = hitpoints;
    }
}
