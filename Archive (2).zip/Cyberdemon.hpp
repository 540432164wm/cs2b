//
//  cyberdemon.hpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#ifndef Cyberdemon_hpp
#define Cyberdemon_hpp
#include "Demon.hpp"
#include <string>
namespace cs_creature{

    class Cyberdemon: public Demon {
    public:
        Cyberdemon();
        Cyberdemon(int newStrength, int newHitpoints );
        std::string getSpecies() const;
    };
}
#endif /* cyberdemon_hpp */

