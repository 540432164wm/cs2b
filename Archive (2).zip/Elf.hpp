//
//  Elf.hpp
//  a7a
//
//  Created by mian wei  on 11/10/17.
//  Copyright © 2017 mian wei. All rights reserved.
//

#ifndef Elf_hpp
#define Elf_hpp
#include "Creature.hpp"
#include <string>
namespace cs_creature{

    class Elf: public Creature {
    public:
        Elf();
        Elf(int newStrength, int newHitpoints );
        int getDamage() const;
        std::string getSpecies() const;
    };
}
#endif /* Elf_hpp */

